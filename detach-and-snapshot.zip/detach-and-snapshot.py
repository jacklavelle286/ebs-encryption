import boto3
import json

def lambda_handler(event, context):
    ec2_client = boto3.client('ec2')

    # Assuming the output of the first function is passed as an input to this function
    instance_block_device_mappings = event['instanceBlockDeviceMappings']

    volume_ids = []
    for instance_id, block_device_mappings in instance_block_device_mappings.items():
        for device_name, volume_id in block_device_mappings.items():
            volume_ids.append(volume_id)

    if not volume_ids:
        return {
            'statusCode': 200,
            'body': 'No volumes to process.',
            'snapshotInfo': []
        }

    snapshot_info = []
    for volume_id in volume_ids:
        volume = ec2_client.describe_volumes(VolumeIds=[volume_id])['Volumes'][0]
        instance_id = volume['Attachments'][0]['InstanceId']  # Assuming each volume is attached to an instance
        
        # Detach the volume
        ec2_client.detach_volume(VolumeId=volume_id, InstanceId=instance_id, Force=True)
        print(f'Detached volume {volume_id} from instance {instance_id}')
        
        # Create a snapshot of the volume
        snapshot = ec2_client.create_snapshot(VolumeId=volume_id, Description=f'Snapshot of {volume_id}')
        snapshot_id = snapshot['SnapshotId']
        snapshot_info.append({
            'SnapshotId': snapshot_id,
            'AvailabilityZone': volume['AvailabilityZone'],
            'InstanceId': instance_id,  # Include the InstanceId
            'BlockDeviceMappings': instance_block_device_mappings.get(instance_id, {})  # Include block device mappings from the input
        })
        print(f'Created snapshot {snapshot_id} for volume {volume_id}')
    
    return {
        'statusCode': 200,
        'body': f'Created {len(snapshot_info)} snapshots.',
        'snapshotInfo': snapshot_info  # Return the snapshot IDs, AZs, and InstanceIds for the next step
    }
