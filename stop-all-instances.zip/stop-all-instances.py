import boto3
import json
import os
from datetime import datetime

def datetime_serializer(obj):
    if isinstance(obj, datetime):
        return obj.isoformat()
    raise TypeError("Type not serializable")

def extract_device_mapping(block_device_mappings):
    devices = {}
    for mapping in block_device_mappings:
        device_name = mapping.get('DeviceName')
        ebs = mapping.get('Ebs', {})
        volume_id = ebs.get('VolumeId')
        devices[device_name] = volume_id
    return devices

def lambda_handler(event, context):
    # Get the tag key from environment variables
    tag_key = os.environ.get('InstanceTag')
    tag_value = 'true'  # Assuming the value of the tag is 'true'
    
    # Create EC2 client
    ec2_client = boto3.client('ec2')
    
    # Describe only running EC2 instances with the specified tag
    response = ec2_client.describe_instances(
        Filters=[
            {
                'Name': 'instance-state-name',
                'Values': ['running']
            },
            {
                'Name': f'tag:{tag_key}',
                'Values': [tag_value]
            }
        ]
    )
    
    instance_ids = []
    instance_block_device_mappings = {}
    
    for reservation in response['Reservations']:
        for instance in reservation['Instances']:
            # Extract instance ID
            instance_id = instance['InstanceId']
            instance_ids.append(instance_id)
            
            # Extract block device mapping
            instance_block_device_mappings[instance_id] = extract_device_mapping(instance['BlockDeviceMappings'])
    
    # Stop all running EC2 instances
    if instance_ids:
        ec2_client.stop_instances(InstanceIds=instance_ids)
    
    # Serialize the response to a JSON string, using the custom datetime_serializer
    response_body = json.dumps({
        'statusCode': 200,
        'body': f'Stopped {len(instance_ids)} instances.',
        'instanceBlockDeviceMappings': instance_block_device_mappings
    }, default=datetime_serializer)
    
    return response_body
