import boto3
import os
import time

def lambda_handler(event, context):
    ec2_client = boto3.client('ec2')

    encrypted_snapshot_info = event['encryptedSnapshotInfo']

    restored_volume_ids = []  # List to store info of restored volumes

    for info in encrypted_snapshot_info:
        instance_id = info['InstanceId']
        encrypted_snapshot_id = info['EncryptedSnapshotId']
        availability_zone = info['AvailabilityZone']
        block_device_mappings = info['BlockDeviceMappings']

        # Create new volume from encrypted snapshot
        response = ec2_client.create_volume(
            SnapshotId=encrypted_snapshot_id,
            AvailabilityZone=availability_zone
        )
        volume_id = response['VolumeId']

        # Extract device name from block_device_mappings
        root_device_name = next(iter(block_device_mappings))

        # Retry logic for attaching the volume
        for attempt in range(3):
            try:
                # Attach the new volume to the original instance
                ec2_client.attach_volume(
                    VolumeId=volume_id,
                    InstanceId=instance_id,
                    Device=root_device_name  # Use the determined device name
                )
                # Wait for a while to ensure the attachment request has been processed
                time.sleep(10)
                
                # Check if the volume is attached
                response = ec2_client.describe_volumes(VolumeIds=[volume_id])
                attachment_state = response['Volumes'][0]['Attachments'][0]['State']
                if attachment_state == 'attached':
                    print(f'Volume {volume_id} successfully attached to instance {instance_id}')
                    break  # Break out of the retry loop if attachment succeeded
            except Exception as e:
                print(f'Error on attempt {attempt + 1} to attach volume {volume_id} to instance {instance_id}: {e}')
                time.sleep(10)  # Wait for 10 seconds before retrying
                
        else:  # This block executes if the for loop completes without breaking (i.e., all retries failed)
            print(f'Failed to attach volume {volume_id} to instance {instance_id} after 3 attempts.')
            continue  # Skip to the next iteration if attachment still fails after 3 retries

        # Convert the volume to gp3
        ec2_client.modify_volume(
            VolumeId=volume_id,
            VolumeType='gp3'
        )

        # Append info of restored volume to restored_volume_ids list
        restored_volume_ids.append({
            'VolumeId': volume_id,
            'InstanceId': instance_id,
            'BlockDeviceMappings': {root_device_name: volume_id}
        })

    # Get all instance IDs from the encrypted_snapshot_info list
    instance_ids = list(set([info['InstanceId'] for info in encrypted_snapshot_info]))

    # Start all instances
    try:
        ec2_client.start_instances(InstanceIds=instance_ids)
    except ec2_client.exceptions.ClientError as e:
        print(f"Error: {e}")

    return {
        'statusCode': 200,
        'body': f'Processed {len(restored_volume_ids)} volumes and started {len(instance_ids)} instances. All of your EBS volumes in your account are encrypted.',
        'restoredVolumeIds': restored_volume_ids  # Return the restored volume IDs and InstanceIds for further processing
    }
