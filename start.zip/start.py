import boto3
import time

def lambda_handler(event, context):
    ec2_client = boto3.client('ec2')

    # Get all stopped instances
    response = ec2_client.describe_instances(
        Filters=[
            {
                'Name': 'instance-state-name',
                'Values': ['stopped']
            }
        ]
    )

    # Extract the instance IDs and volume IDs
    instance_ids = []
    volume_ids = []
    for reservation in response['Reservations']:
        for instance in reservation['Instances']:
            instance_ids.append(instance['InstanceId'])
            for block_device_mapping in instance['BlockDeviceMappings']:
                volume_ids.append(block_device_mapping['Ebs']['VolumeId'])

    # Convert the volumes to gp3
    for volume_id in volume_ids:
        ec2_client.modify_volume(
            VolumeId=volume_id,
            VolumeType='gp3'
        )

    # Start all instances
    if instance_ids:
        ec2_client.start_instances(InstanceIds=instance_ids)

    return {
        'statusCode': 200,
        'body': f'Processed {len(volume_ids)} volumes and started {len(instance_ids)} instances. All of your EBS volumes in your account are encrypted.'
    }
