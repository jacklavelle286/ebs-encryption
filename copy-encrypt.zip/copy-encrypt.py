import boto3
import os

def lambda_handler(event, context):
    ec2_client = boto3.client('ec2')

    # Assuming the output of the previous function is passed as an input to this function
    snapshot_info = event['snapshotInfo']

    encrypted_snapshot_info = []
    for info in snapshot_info:
        snapshot_id = info['SnapshotId']
        az = info['AvailabilityZone']
        instance_id = info['InstanceId']
        block_device_mappings = info['BlockDeviceMappings']  # Extract BlockDeviceMappings from input
        
        # Copy the snapshot and encrypt it using the default KMS key
        encrypted_snapshot = ec2_client.copy_snapshot(
            SourceSnapshotId=snapshot_id,
            SourceRegion='us-east-1',  # Replace with the region your snapshots are in
            Encrypted=True
        )
        encrypted_snapshot_id = encrypted_snapshot['SnapshotId']
        encrypted_snapshot_info.append({
            'EncryptedSnapshotId': encrypted_snapshot_id,
            'AvailabilityZone': az,
            'InstanceId': instance_id,  # Include the InstanceId
            'BlockDeviceMappings': block_device_mappings  # Include block device mappings from input
        })
        print(f'Created encrypted snapshot {encrypted_snapshot_id} from snapshot {snapshot_id}')
    
    return {
        'statusCode': 200,
        'body': f'Created {len(encrypted_snapshot_info)} encrypted snapshots.',
        'encryptedSnapshotInfo': encrypted_snapshot_info  # Return the encrypted snapshot IDs and AZs for the next step
    }
